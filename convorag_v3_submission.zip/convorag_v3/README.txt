
ConvoRAG v3 — Sync Architecture Upgrade
=========================================

What changed from v2
─────────────────────
THREE gaps are fixed:

  Gap 1 — Sessions were ephemeral (died on restart)
  Fix   → core/db.py stores chat sessions + messages in SQLite (convorag.db)

  Gap 2 — Same Groq prompt billed twice on re-deploy
  Fix   → groq_call() hashes prompt with sha256; hits cache before every API call

  Gap 3 — Contradiction pairs were hardcoded (needed redeploy to change)
  Fix   → Pairs live in contradiction_pairs table; editable via API live

No new pip dependencies — sqlite3 is Python stdlib.


Folder structure
─────────────────
convorag_v3/
├── app.py                     ← Main Flask server (v3)
├── requirements.txt
├── .env                       ← GROQ_API_KEY here
├── conversations.csv          ← your CSV
├── convorag.db                ← auto-created on first run
├── core/
│   ├── db.py                  ← NEW: SQLite layer
│   ├── conflict_resolver.py   ← updated: loads pairs from DB
│   ├── persona_engine.py      ← unchanged
│   ├── intent_classifier.py   ← unchanged
│   └── __init__.py
├── models/
│   └── intent_model.pkl
└── static/
    └── index.html


How to run (local)
───────────────────
1.  cd convorag_v3

2.  python -m venv venv
    Windows:   venv\Scripts\activate
    Mac/Linux: source venv/bin/activate

3.  pip install -r requirements.txt

4.  Check .env has:  GROQ_API_KEY=gsk_...

5.  python app.py

6.  Open: http://localhost:5000

convorag.db is created automatically on first run.


Render / Docker deployment
───────────────────────────
Add a persistent disk at /data and set env vars:
    DB_PATH=/data/convorag.db
    CSV_PATH=/data/conversations.csv
Build: pip install -r requirements.txt
Start: python app.py


New endpoints (v3)
───────────────────
GET    /api/sessions                       list sessions
GET    /api/sessions/<id>                  full history + persona
DELETE /api/sessions/<id>                  wipe session
GET    /api/groq/cache/stats               cache hit count + savings
GET    /api/contradiction_pairs            list all pairs
POST   /api/contradiction_pairs            add pair (live, no restart)
PATCH  /api/contradiction_pairs/<id>       toggle active/inactive

POST /api/chat now accepts session_id in body; returns it in response.
All other endpoints unchanged — full backward compat with v2 frontend.
