# ConvoRAG v3 — Conversation Intelligence System

> Offline-first RAG over personal chat history, with persistent sessions, idempotent LLM calls, and live-editable conflict resolution rules.

---

## What it does

ConvoRAG ingests a CSV of chat conversations and gives you five tools:

| Tab | What it does | API calls? |
|-----|-------------|------------|
| **Persona Drift** | Tracks tone/mood per day, detects drift triggers | ❌ 100% local |
| **Intent Classifier** | TF-IDF + SGD, 5 classes, ~4ms, 94KB model | ❌ 100% local |
| **Conflict Resolver** | RAG over chunks, scores by recency + emotion, flags contradictions | ❌ 100% local |
| **RAG Query** | Keyword retrieval → Groq summarisation | ✅ Groq |
| **Chatbot** | Persistent session chat with RAG context + persona | ✅ Groq |

---

## v3 Architecture — What Changed

v2 had three silent failure modes. v3 fixes all of them.

### Gap 1 — Sessions died on restart
**v2**: Chat history lived in Flask process memory. Every restart wiped it.  
**v3**: `core/db.py` persists sessions, messages, and personas to SQLite (`convorag.db`). History survives restarts, crashes, and redeployments.

```
chat_sessions   → session_id, persona_json, timestamps
chat_messages   → session_id FK, role, content, created_at
```

### Gap 2 — Same Groq prompt billed twice on redeploy
**v2**: Every API call went straight to Groq. Re-deploying = re-summarising the same 100-message chunks = wasted tokens.  
**v3**: `groq_call()` hashes `sha256(model + system + prompt)` before every call. Cache hit → instant return, zero cost. Check savings at `GET /api/groq/cache/stats`.

```
groq_cache  → cache_key (sha256), model, response, hit_count
```

### Gap 3 — Contradiction pairs needed a redeploy to update
**v2**: Antonym sets were hardcoded in `conflict_resolver.py`. Changing them = edit file + restart.  
**v3**: Pairs live in `contradiction_pairs` table. `ConflictResolver.resolve()` reloads from DB on every call. Add or disable pairs live via REST — no restart needed.

```
contradiction_pairs  → id, pos_words (JSON), neg_words (JSON), active
```

> No new pip dependencies — `sqlite3` is Python stdlib.

---

## Sync Architecture

```
┌─────────────────────────────────────────────────┐
│  ON-DEVICE  (local, free, instant)              │
│  conversations.csv  │  intent_model.pkl          │
│  TOPIC_SEGMENTS     │  CHUNKS_100 (in-memory)   │
│  Persona timeline   │  Flask session → SQLite   │
└──────────┬──────────────────────────────────────┘
           │ topic detect / chunk summaries / chat
           ▼
┌─────────────────────────────────────────────────┐
│  GROQ  (llama-3.3-70b-versatile)                │
│  Topic classify │ Summarise chunks │ Answer      │
└──────────┬──────────────────────────────────────┘
           │ returns summary → cached in SQLite
           ▼
┌─────────────────────────────────────────────────┐
│  CONFLICT RESOLVER  (always local)              │
│  1 Retrieve → 2 Score → 3 Detect → 4 Merge      │
│  Pairs loaded from DB on every query            │
└─────────────────────────────────────────────────┘
```

**What never leaves the device:** persona drift, intent classification, conflict resolution, raw messages.  
**What syncs:** 100-message windows for topic detection, chunk summaries, chat turns.

---

## Quickstart

```bash
git clone https://github.com/YOUR_USERNAME/convorag-v3
cd convorag-v3

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env
# Edit .env — add your GROQ_API_KEY (free at console.groq.com)

# Place your conversations.csv in the root folder
python app.py
```

Open **http://localhost:5000**

`convorag.db` is created automatically on first run.

---

## Deploy on Render

1. Push to GitHub
2. New Web Service → connect repo
3. Add a **Persistent Disk** mounted at `/data`
4. Environment variables:
   ```
   GROQ_API_KEY=gsk_...
   DB_PATH=/data/convorag.db
   CSV_PATH=/data/conversations.csv
   ```
5. Build: `pip install -r requirements.txt`
6. Start: `python app.py`

Without the persistent disk, `convorag.db` resets on every deploy and you lose all session history.

---

## API Reference

### Original endpoints (unchanged — v2 compatible)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/info` | System info + cache stats |
| POST | `/api/persona/drift` | `{ "days": 15 }` |
| GET | `/api/persona/timeline` | First 15 days |
| POST | `/api/intent` | `{ "message": "..." }` |
| POST | `/api/intent/batch` | `{ "messages": [...] }` |
| GET | `/api/intent/demo` | 20 sample classifications |
| POST | `/api/rag/resolve` | `{ "query": "..." }` |
| POST | `/api/rag/query` | RAG + Groq answer |
| POST | `/api/chat` | Chat turn |
| POST | `/api/extract_persona` | Extract persona from CSV |

### New in v3

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/sessions` | List all sessions |
| GET | `/api/sessions/<id>` | Messages + persona for session |
| DELETE | `/api/sessions/<id>` | Wipe session |
| GET | `/api/groq/cache/stats` | `{ total, total_hits, last_write }` |
| GET | `/api/contradiction_pairs` | List all pairs |
| POST | `/api/contradiction_pairs` | Add pair (live, no restart) |
| PATCH | `/api/contradiction_pairs/<id>` | `{ "active": false }` toggle |

### Chat session flow (v3)

```json
// Request
POST /api/chat
{ "messages": [{"role":"user","content":"hi"}], "session_id": "abc-123" }

// Response
{ "reply": "Hello! ...", "session_id": "abc-123" }
```

Store `session_id` client-side and send it on every request. Omit it to start a new session.

### Add a contradiction pair live

```bash
curl -X POST http://localhost:5000/api/contradiction_pairs \
  -H "Content-Type: application/json" \
  -d '{"pos_words":["promoted","raise","bonus"],"neg_words":["fired","layoff","unemployed"],"label":"job-status"}'
```

Active immediately on the next `/api/rag/resolve` call.

---

## Project Structure

```
convorag_v3/
├── app.py                    Main Flask server
├── requirements.txt
├── .env.example
├── core/
│   ├── db.py                 SQLite: sessions, cache, contradiction pairs
│   ├── conflict_resolver.py  DB-backed contradiction detection
│   ├── persona_engine.py     Tone/mood drift detector (local)
│   └── intent_classifier.py  TF-IDF intent classifier (local)
├── models/
│   └── intent_model.pkl      Auto-trained on first run
└── static/
    └── index.html            Frontend UI
```

---

## Local vs API

| Feature | Where it runs | Cost |
|---------|--------------|------|
| CSV parsing | Local | Free |
| Persona drift | Local | Free |
| Intent classification | Local | Free |
| Conflict resolution | Local | Free |
| Topic detection | Groq (cached) | ~0 after first run |
| Chunk summaries | Groq (cached) | ~0 after first run |
| Chat answers | Groq (not cached) | Per turn |

---

## License

MIT
